let unlockedAchievements = JSON.parse(localStorage.getItem("unlockedAchievements") || "[]");
let usedWords = JSON.parse(localStorage.getItem("usedWords") || "{}");
for (const c in CATEGORIES) if (!usedWords[c]) usedWords[c] = [];
let unlockedLevels = JSON.parse(localStorage.getItem("unlockedLevels") || "{}");
const diffs = ["easy", "medium", "hard"];  const cats  = Object.keys(CATEGORIES); 
for (const d of diffs) { if (!unlockedLevels[d]) unlockedLevels[d] = {}; for (const c of cats) { if (!unlockedLevels[d][c]) { unlockedLevels[d][c] = [1]; } } }
let coins = Number(localStorage.getItem("coins"));
if (!Number.isFinite(coins)) coins = 0;


if (localStorage.getItem("daily_" + today) === "done") {
  alert("✅ You've already completed today's puzzle!");
  return;
}
localStorage.setItem("daily_" + today, "done");

localStorage.setItem("coins", coins);

const key = `${currentDifficulty}-${currentCat}-level${lockedLevel}`;
const saved = JSON.parse(localStorage.getItem(key) || "{}");

localStorage.setItem("coins", coins);
localStorage.setItem(key, JSON.stringify(saved));


localStorage.setItem("coins", coins);

const key = `${currentDifficulty}-${currentCat}-level${currentLevel}`;
const savedData = JSON.parse(localStorage.getItem(key) || "{}");

levelCompleted = !!savedData.completed;
  currentMode = (typeof currentMode === 'string' && currentMode !== '') ? currentMode : "normal";

if (savedData && savedData.placed && savedData.found) {
  placedWords = savedData.placed;
  foundWords = new Set(savedData.found);
  foundColors = savedData.colors || {};
  boardData = Array.from({ length: settings.size }, () => Array(settings.size).fill(''));
  for (const [word, coords] of Object.entries(placedWords)) {
    coords.forEach(([r, c], i) => boardData[r][c] = word[i]);
  }
  for (let r = 0; r < settings.size; r++)
    for (let c = 0; c < settings.size; c++)
      if (!boardData[r][c])
        boardData[r][c] = String.fromCharCode(65 + Math.floor(Math.random() * 26));
  renderGrid(settings.size);
  triggerLevelIntro("#grid");
  renderWordList(Object.keys(placedWords));
  triggerWordListSlideIn();
  if (currentMode === 'blind-list') {
    hideWordList();
  }
  for (const w of foundWords) {
    const coords = placedWords[w];
    const color = foundColors[w] || 'yellow';
    coords.forEach(([r, c]) => {
      const el = document.querySelector(`.cell[data-row="${r}"][data-col="${c}"]`);
      if (el) {
        el.style.background = color;
        el.classList.add('perma');
      }
    });
    const wordEl = document.getElementById(`word-${w}`);
    if (wordEl) wordEl.classList.add('word-found');
  }
}
localStorage.setItem("usedWords", JSON.stringify(usedWords));

if (!unlockedLevels[diff]) unlockedLevels[diff] = {};
if (!Array.isArray(unlockedLevels[diff][cat])) {
  unlockedLevels[diff][cat] = [1];
}
if (!unlockedLevels[diff][cat].includes(nextLevel)) {
  unlockedLevels[diff][cat].push(nextLevel);
  unlockedLevels[diff][cat].sort((a, b) => a - b);
  localStorage.setItem("unlockedLevels", JSON.stringify(unlockedLevels));
  console.log(` Level ${nextLevel} unlocked in ${cat} (${diff})`);
}

function saveProgress() {
  try {
    const key = `${currentDifficulty}-${currentCat}-level${currentLevel}`;
    const data = {
      found: [...foundWords],
      placed: placedWords,
      colors: foundColors
    };
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.error("Save failed:", e);
  }
}
function resetGame() {
  const key = `${currentDifficulty}-${currentCat}-level${currentLevel}`;
  const saved = JSON.parse(localStorage.getItem(key) || "{}");
  if (saved.placed) {
    saved.found = [];
    saved.colors = {};
    delete saved.completed;
    localStorage.setItem(key, JSON.stringify(saved));
  }
  foundWords.clear();
  foundColors = {};
  document.querySelectorAll('.cell').forEach(c => {
    c.classList.remove('perma');
    c.style.background = '';
  });
  document.querySelectorAll('.word-item').forEach(w => w.classList.remove('word-found'));
}
const clearBtn = document.getElementById('clearLevelBtn');
if (clearBtn) {
  clearBtn.addEventListener('click', function () {
    waitForButtonActive(function () {
      const key = `${currentDifficulty}-${currentCat}-level${currentLevel}`;
      const saved = JSON.parse(localStorage.getItem(key) || "{}");
      if (saved.placed) {
        localStorage.setItem(key, JSON.stringify({
          placed: saved.placed,
          found: [],
          colors: {}
        }));
      }
      foundWords.clear();
      foundColors = {};
      document.querySelectorAll('.cell').forEach(c => {
        c.classList.remove('perma');
        c.style.background = '';
      });
      document.querySelectorAll('.word-item').forEach(w => w.classList.remove('word-found'));
    });
  });
}
function clearLocalStorage() {
  const savedCoins = localStorage.getItem("coins");
  const savedHints = localStorage.getItem("hints");
  localStorage.clear();
  unlockedThemes = ["DEFAULT"];
  unlockedLevels = {};
  unlockedachievements = {};
  for (const cat in CATEGORIES) {
    unlockedLevels[cat] = [1];
  }
  localStorage.setItem("unlockedThemes", JSON.stringify(unlockedThemes));
  localStorage.setItem("unlockedLevels", JSON.stringify(unlockedLevels));
  localStorage.setItem("usedWords", JSON.stringify({}));
  if (savedCoins !== null) localStorage.setItem("coins", savedCoins);
  if (savedHints !== null) localStorage.setItem("hints", savedHints);
  updateHintDisplay();
  updateCoinDisplay();
  foundWords.clear();
  foundColors = {};
  levelCompleted = false;
  showPopup("✅ Game data cleared! Coins and hints are safe.");
  goto("start");
}

const completed = localStorage.getItem("daily_" + today);

if (completed) {
  statusEl.textContent = " You already completed today's Daily Puzzle!";
  if (playBtn) {
    playBtn.disabled = true;
    playBtn.textContent = "Completed";
    playBtn.style.opacity = "0.6";
  }
}

const completed = localStorage.getItem("daily_" + today);

const KEY_LAST = "daily_last_claim";
const KEY_STREAK = "daily_streak_day";

const last = localStorage.getItem(KEY_LAST);
const streakDay = Number(localStorage.getItem(KEY_STREAK) || "1");

 localStorage.setItem("coins", coins);

localStorage.setItem("hints", hints);
localStorage.setItem("persistentHintsBackup", hints);
updateHintDisplay?.();
localStorage.setItem(KEY_LAST, todayStr());

localStorage.setItem("daily_legend_unlocked", "1");


localStorage.setItem(KEY_STREAK, "1");
      localStorage.setItem(KEY_STREAK, String(streakDay + 1));


const name = localStorage.getItem("playerName") || "Player";
const completed = Object.keys(localStorage)


Object.keys(localStorage).forEach(k => {
      if (k.includes("-level")) {
        try {
          const data = JSON.parse(localStorage.getItem(k));
          if (data.found && Array.isArray(data.found)) totalWords += data.found.length;
        } catch {}
      }
    }
    
const achievements = JSON.parse(localStorage.getItem("unlockedAchievements") || "[]").length;
const coins = Number(localStorage.getItem("coins") || 0);
const themeIndex = Number(localStorage.getItem("theme")) || 0;
const themeName = THEMES[themeIndex]?.name || "Default";
const nameEl = document.getElementById("player-name");
const progressEl = document.getElementById("profile-progress");
const wordsEl = document.getElementById("profile-words");
const achievementsEl = document.getElementById("profile-achievements");
const themeEl = document.getElementById("profile-theme");
const coinsEl = document.getElementById("profile-coins");


function getSavedCoins() {
  const saved = Number(localStorage.getItem("coins"));
  return isNaN(saved) ? 0 : saved;
}
  coins = Number(localStorage.getItem("coins") || coins || 0);

  const stored = localStorage.getItem("persistentHintsBackup");
  hints = stored !== null ? Number(stored) : 3; 

let enabled = localStorage.getItem("colorblind") === "1";
localStorage.setItem("colorblind", enabled ? "1" : "0");

  let enabled = localStorage.getItem("performance") === "1";
  localStorage.setItem("performance", enabled ? "1" : "0");

const cb = localStorage.getItem("colorblind") === "1";
const perf = localStorage.getItem("performance") === "1";

const totalCompleted = Object.keys(localStorage)
  const totalWordsFound = foundWords ? foundWords.size : 0;
  const totalColors = foundColors ? Object.keys(foundColors).length : 0;
  const hours = new Date().getHours();

function saveAchievements() { localStorage.setItem("unlockedAchievements", JSON.stringify(unlockedAchievements)); }






document.addEventListener("DOMContentLoaded", () => {
  const popup = document.getElementById("achievement-detail-popup");
  const titleEl = document.getElementById("popup-achievement-title");
  const descEl = document.getElementById("popup-achievement-desc");
  const okBtn = document.getElementById("popup-ok-btn");
  okBtn.addEventListener("click", function () {
  waitForButtonActive(function () {
    popup.classList.add("hidden");
  });
});
  if (true) {
    
  }document.getElementById("achievements-screen").addEventListener("click", (e) => {
    const btn = e.target.closest(".achievement-btn");
    if (!btn) return;
    const id = btn.dataset.id;
    const ach = ACHIEVEMENTS.find(a => a.id === id);
    if (!ach) return;
    titleEl.textContent = ach.name;
    descEl.textContent = ach.desc;
    popup.classList.remove("hidden");
  });
});
