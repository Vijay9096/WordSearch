const settings = { size: 10, words: 10 };
let currentCat = "";
let currentLevel = 0;
let placedWords = {};
let foundWords = new Set();
let animationsEnabled = true;
let foundColors = {};
let boardData = [];
let levelCompleted = false;
let currentMode = "normal";
let hints;

let unlockedAchievements = JSON.parse(localStorage.getItem("unlockedAchievements") || "[]");
let usedWords = JSON.parse(localStorage.getItem("usedWords") || "{}");
for (const c in CATEGORIES) if (!usedWords[c]) usedWords[c] = [];
let unlockedLevels = JSON.parse(localStorage.getItem("unlockedLevels") || "{}");
const diffs = ["easy", "medium", "hard"];  const cats  = Object.keys(CATEGORIES); 
for (const d of diffs) { if (!unlockedLevels[d]) unlockedLevels[d] = {}; for (const c of cats) { if (!unlockedLevels[d][c]) { unlockedLevels[d][c] = [1]; } } }
let coins = Number(localStorage.getItem("coins"));
if (!Number.isFinite(coins)) coins = 0;