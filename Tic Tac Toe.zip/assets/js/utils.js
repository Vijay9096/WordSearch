function updateCoinDisplay() {
  const el = document.getElementById("coinCount");
  if (el) el.textContent = coins;
}

function updateHintDisplay() {
  const el = document.getElementById("hintCount");
  if (el) el.textContent = hints;
}
function addReward(amount) {
  amount = Number(amount) || 0;
  if (amount <= 0) return;
  coins = Number(coins) || 0;         // use your global `coins` var
  coins += amount;
  localStorage.setItem('coins', coins);
  updateCoinDisplay();
  if (typeof updateCoinDisplay === 'function') updateCoinDisplay();
}
// undoMove: works for local and AI modes.
// - local: undo last single move
// - ai mode: undo last two moves (AI + player) if available, otherwise undo what's available
function undoMove() {
  if (!moveHistory || !moveHistory.length) return false;

  // helper to clear one history item
  function clearOne() {
    const last = moveHistory.pop();
    if (!last) return;
    board[last.index] = null;
    const cell = document.querySelector(`[data-index="${last.index}"]`);
    if (cell) {
      cell.textContent = "";
      cell.classList.remove("x", "o");
      cell.style.boxShadow = "";
      cell.style.background = "";
    }
    return last;
  }

  if (mode === "ai") {
    // prefer reverting both AI+player to return game to the player's turn
    // if only one move exists, just undo that one
    if (moveHistory.length >= 2) {
      // pop AI move first (usually the last), then pop player's move
      const last1 = clearOne(); // should be AI or player depending on timing
      const last2 = clearOne(); // the other move
      // set currentPlayer to the player who should move now:
      // prefer setting to the player of last2 (the one who made the player's move)
      if (last2 && last2.player) currentPlayer = last2.player;
      else currentPlayer = "X";
      running = true;
      const status = document.getElementById("gameStatus");
      if (status) status.textContent = `Turn: ${currentPlayer}`;
      return true;
    } else {
      // only one move available — undo it
      const last = clearOne();
      if (last && last.player) currentPlayer = last.player;
      else currentPlayer = "X";
      running = true;
      const status = document.getElementById("gameStatus");
      if (status) status.textContent = `Turn: ${currentPlayer}`;
      return true;
    }
  } else {
    // local mode: undo single last move
    const last = clearOne();
    if (last && last.player) currentPlayer = last.player;
    else currentPlayer = "X";
    running = true;
    const status = document.getElementById("gameStatus");
    if (status) status.textContent = `Turn: ${currentPlayer}`;
    return true;
  }
}
// settings.js

function toggleAnimations() {
  animationsEnabled = !animationsEnabled;
  const btn = document.getElementById("toggle-animation-btn");
  if (btn) btn.textContent = animationsEnabled ? "✨ Animations: ON" : "✨ Animations: OFF";
  // optionally persist:
  try { localStorage.setItem('animationsEnabled', animationsEnabled ? '1' : '0'); } catch {}
}

function toggleLimitedPieces() {
  limitedPiecesEnabled = !limitedPiecesEnabled;
  const btn = document.getElementById("toggle-limit-btn");
  if (btn) btn.textContent = limitedPiecesEnabled ? "♟ Limited Pieces: ON" : "♟ Limited Pieces: OFF";
  try { localStorage.setItem('limitedPiecesEnabled', limitedPiecesEnabled ? '1' : '0'); } catch {}
}

// initialize toggle states on load
document.addEventListener('DOMContentLoaded', () => {
  try {
    animationsEnabled = localStorage.getItem('animationsEnabled') === '1' ? true : animationsEnabled;
    limitedPiecesEnabled = localStorage.getItem('limitedPiecesEnabled') === '1' ? true : limitedPiecesEnabled;
  } catch (e) {}
  const aBtn = document.getElementById("toggle-animation-btn");
  if (aBtn) aBtn.textContent = animationsEnabled ? "✨ Animations: ON" : "✨ Animations: OFF";
  const lBtn = document.getElementById("toggle-limit-btn");
  if (lBtn) lBtn.textContent = limitedPiecesEnabled ? "♟ Limited Pieces: ON" : "♟ Limited Pieces: OFF";
});