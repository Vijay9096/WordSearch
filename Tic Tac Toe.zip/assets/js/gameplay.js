// assets/js/gameplay.js
// Only real functions. Globals come from global.js

// ================= CREATE BOARD =================
function createBoard(size) {
  boardSize = Number(size);
  winLen = boardSize;
  board = Array(boardSize * boardSize).fill(null);
  
  const grid = document.getElementById("grid");
  if (!grid) return;
  
  grid.innerHTML = "";
  grid.classList.add("grid");
  grid.style.gridTemplateColumns = `repeat(${boardSize}, 1fr)`;
  
  for (let i = 0; i < boardSize * boardSize; i++) {
    const cell = document.createElement("div");
    cell.className = "cell";
    cell.dataset.index = i;
    cell.textContent = "";
    cell.onclick = function() {
      onCellClick(i);
    };
    grid.appendChild(cell);
  }
  
  const title = document.getElementById("game-title");
  if (title) {
    title.textContent = `${boardSize}×${boardSize} - ${mode === "ai" ? "VS AI" : "2 Players"}`;
  }
  
  const status = document.getElementById("gameStatus");
  if (status) status.textContent = `Turn: ${currentPlayer}`;
}


// ================= START GAME =================
function startGame(size, newMode = mode, diff = difficulty) {
  boardSize = Number(size);
  mode = newMode;
  difficulty = diff;
  currentPlayer = "X";
  running = true;
  
  createBoard(boardSize);
  
  if (typeof goto === "function") goto("game");
}


// ================= HANDLE CELL CLICK =================
function onCellClick(index) {
  if (!running) return;
  if (board[index] !== null) return;
  
  makeMove(index);
  
  if (running && mode === "ai" && currentPlayer === "O") {
    setTimeout(function() {
      aiMove();
    }, 180);
  }
}


// ================= PLACE MOVE =================
function makeMove(index) {
  if (!running) return;
  if (board[index] !== null) return;
  
  moveHistory.push({ index, player: currentPlayer });
  
  board[index] = currentPlayer;
  
  const cell = document.querySelector(`[data-index="${index}"]`);
  if (cell) {
    cell.textContent = currentPlayer;
    cell.classList.remove("x", "o");
    cell.classList.add(currentPlayer.toLowerCase());
  }
  // after updating UI & pushing to moveHistory (inside makeMove)
  enforcePieceLimitFor(currentPlayer);
  const result = checkWinner(board, boardSize, winLen);
  
  if (result) {
  running = false;
  highlightCells(result.line);

  // reward only when mode is 'ai' AND the human won.
  // assuming human is 'X' and ai is 'O' (your globals)
  if (mode === "ai" && result.player === "X") {
  addReward(30)
}

  showGameFinished(`${result.player} wins!`);
  return;
}
  
  if (board.every(v => v !== null)) {
    running = false;
    showGameFinished("It's a draw!");
    return;
  }
  
  currentPlayer = currentPlayer === "X" ? "O" : "X";
  const status = document.getElementById("gameStatus");
  if (status) status.textContent = `Turn: ${currentPlayer}`;
}

// gameplay.js (add this once)
function enforcePieceLimitFor(player) {
  if (!limitedPiecesEnabled) return;
  if (!Array.isArray(moveHistory)) return;

  // collect current positions for player in chronological order by moveHistory
  const playerMoves = [];
  for (let i = 0; i < moveHistory.length; i++) {
    const m = moveHistory[i];
    if (m && m.player === player && board[m.index] === player) playerMoves.push({ index: m.index, historyIndex: i });
  }

  // remove oldest while exceeding limit
  while (playerMoves.length > maxPiecesPerPlayer) {
    const oldest = playerMoves.shift(); // removes first (oldest)
    if (!oldest) break;
    // clear board
    board[oldest.index] = null;
    // clear UI
    const cell = document.querySelector(`[data-index="${oldest.index}"]`);
    if (cell) {
      cell.textContent = '';
      cell.classList.remove('x','o');
      cell.style.boxShadow = '';
      cell.style.background = '';
    }
    // remove all history entries for that index (keep history consistent)
    for (let h = moveHistory.length - 1; h >= 0; h--) {
      if (moveHistory[h] && moveHistory[h].index === oldest.index) moveHistory.splice(h, 1);
    }
    // recompute playerMoves: simplest is to rebuild and continue loop
    playerMoves.length = 0;
    for (let i = 0; i < moveHistory.length; i++) {
      const m = moveHistory[i];
      if (m && m.player === player && board[m.index] === player) playerMoves.push({ index: m.index, historyIndex: i });
    }
  }
}

// ================= CHECK WINNER =================
function checkWinner(b, size, wlen) {
  function at(r, c) {
    return (r < 0 || c < 0 || r >= size || c >= size) ? null : b[r * size + c];
  }
  
  const dirs = [
    { r: 0, c: 1 },
    { r: 1, c: 0 },
    { r: 1, c: 1 },
    { r: 1, c: -1 }
  ];
  
  for (let r = 0; r < size; r++) {
    for (let c = 0; c < size; c++) {
      const start = at(r, c);
      if (!start) continue;
      
      for (let d = 0; d < dirs.length; d++) {
        const line = [r * size + c];
        let ok = true;
        
        for (let k = 1; k < wlen; k++) {
          const rr = r + dirs[d].r * k;
          const cc = c + dirs[d].c * k;
          
          if (at(rr, cc) !== start) {
            ok = false;
            break;
          }
          
          line.push(rr * size + cc);
        }
        
        if (ok) return { player: start, line };
      }
    }
  }
  
  return null;
}


// ================= HIGHLIGHT CELLS =================
function highlightCells(line) {
  if (!Array.isArray(line)) return;
  line.forEach(i => {
    const cell = document.querySelector(`[data-index="${i}"]`);
    if (cell) {
      cell.style.boxShadow = "none";
      cell.style.backgroundColor = "#F4A900";
    }
  });
}

// ================= AI MOVE =================
// AI move: easy / normal / hard
function aiMove() {
  if (!running) return;
  const size = Number(boardSize) || 3;
  const ai = aiPlaysAs || 'O';
  const human = ai === 'X' ? 'O' : 'X';

  // helpers
  function empties(b) {
    return b.map((v,i) => v === null ? i : null).filter(v => v !== null);
  }
  function pickRandom(b) {
    const e = empties(b);
    if (!e.length) return null;
    return e[Math.floor(Math.random() * e.length)];
  }
  function findImmediate(b, player) {
    const e = empties(b);
    for (const i of e) {
      b[i] = player;
      const r = checkWinner(b, size, winLen);
      b[i] = null;
      if (r && r.player === player) return i;
    }
    return null;
  }

  // minimax for 3x3 only (returns {index,score})
  function minimax(bState, player, depth, maxDepth) {
    const avail = empties(bState);
    const res = checkWinner(bState, 3, 3);
    if (res) return { score: res.player === ai ? 10 - depth : depth - 10 };
    if (!avail.length) return { score: 0 };
    if (depth >= maxDepth) return { score: 0, index: avail[0] };

    const moves = [];
    for (const i of avail) {
      bState[i] = player;
      const next = minimax(bState, player === 'X' ? 'O' : 'X', depth + 1, maxDepth);
      moves.push({ index: i, score: next.score });
      bState[i] = null;
    }
    let best = null;
    if (player === ai) {
      let bestScore = -Infinity;
      for (const m of moves) if (m.score > bestScore) { bestScore = m.score; best = m; }
    } else {
      let bestScore = Infinity;
      for (const m of moves) if (m.score < bestScore) { bestScore = m.score; best = m; }
    }
    return best || { score: 0, index: avail[0] };
  }

  // choose move based on difficulty
  let pick = null;
  if (difficulty === 'easy') {
    // mostly random, sometimes smart
    if (Math.random() < 0.6) {
      pick = pickRandom(board);
    } else {
      pick = findImmediate(board, ai) || findImmediate(board, human) || pickRandom(board);
    }
  } else if (difficulty === 'normal') {
    // always try win, then block, then center, else random
    pick = findImmediate(board, ai);
    if (pick === null) pick = findImmediate(board, human);
    if (pick === null) {
      const center = Math.floor((size * size) / 2);
      if (board[center] === null) pick = center;
    }
    if (pick === null) pick = pickRandom(board);
  } else { // hard
    if (size === 3) {
      // deep minimax (effectively unbeatable)
      const res = minimax(board.slice(), ai, 0, 9);
      pick = (res && typeof res.index === 'number') ? res.index : pickRandom(board);
    } else {
      // larger boards: greedy like normal, but prefer forks by trying each move and scoring
      pick = findImmediate(board, ai) || findImmediate(board, human);
      if (pick === null) {
        const center = Math.floor((size * size) / 2);
        if (board[center] === null) pick = center;
      }
      if (pick === null) {
        // tiny lookahead: try each empty and choose move that creates most two-in-a-row for AI
        const empt = empties(board);
        let bestScore = -Infinity;
        for (const idx of empt) {
          board[idx] = ai;
          // score = number of immediate 2-in-row lines (simple heuristic)
          let score = 0;
          // scan all empties: if placing human anywhere would win, reduce score
          if (checkWinner(board, size, winLen)) score += 100;
          for (const j of empt) {
            if (board[j] === null) {
              board[j] = ai;
              if (checkWinner(board, size, Math.min(2, winLen))) score += 1;
              board[j] = null;
            }
          }
          board[idx] = null;
          if (score > bestScore) { bestScore = score; pick = idx; }
        }
        if (pick === null) pick = pickRandom(board);
      }
    }
  }

  if (pick === null) pick = pickRandom(board);
  if (pick === null) return;
  makeMove(pick);
}

// ================= POPUP =================
function showGameFinished(message) {
  const popup = document.getElementById("game-finished");
  if (!popup) return;
  
  const msg = popup.querySelector(".popup-message");
  if (msg) msg.textContent = message;
  
  popup.classList.remove("hidden");
}

function hideGameFinished() {
  const popup = document.getElementById("game-finished");
  if (popup) popup.classList.add("hidden");
}


// ================= POPUP BUTTONS =================
document.addEventListener("DOMContentLoaded", function() {
  const restartBtn = document.getElementById("closePopup");
  const backBtn = document.getElementById("back");
  
  if (restartBtn) {
    restartBtn.onclick = function() {
      hideGameFinished();
      startGame(boardSize, mode, difficulty);
    };
  }
  
  if (backBtn) {
    backBtn.onclick = function() {
      hideGameFinished();
      goto("board-screen");
    };
  }
  
  createBoard(boardSize);
});
document.addEventListener('DOMContentLoaded', () => {
  if (typeof loadLocalStorage === 'function') loadLocalStorage();
  updateCoinDisplay(); // coins loaded → now show
  createBoard(boardSize); // safe now
});