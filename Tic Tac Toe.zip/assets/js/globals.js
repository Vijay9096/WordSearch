let boardSize = 3;
let board = [];
let currentPlayer = "X";
let aiPlaysAs = "O";
let moveHistory = [];

let animationsEnabled = true;
let limitedPiecesEnabled = false;
let maxPiecesPerPlayer = 3;

let playerXName = localStorage.getItem('ttt_playerX') || 'Player X';
let playerOName = localStorage.getItem('ttt_playerO') || 'Player O';
let mode = "local";
let difficulty = "normal";
let running = false;
let winLen = 3;

let hints;
let coins = Number(localStorage.getItem("coins") || 0);

const KEY_SCORES = 'ttt_scores';
const KEY_HISTORY = 'ttt_history';
const KEY_PLAYER_NAMES = 'ttt_playerNames';