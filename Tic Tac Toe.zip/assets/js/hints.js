function useHint() {
  if (hints <= 0) {
    showPopup("⚠️ No hints left!");
    return;
  }

  const idx = getHintIndex();
  if (idx === null) {
    showPopup("⚠️ No valid hint!");
    return;
  }

  // spend one hint
  hints--;
  updateHintDisplay();
  localStorage.setItem("hints", hints);

  const cell = document.querySelector(`[data-index="${idx}"]`);
  if (!cell) return;

  // very simple highlight (no animation)
  const oldBg = cell.style.background;
  cell.style.background = "#ffe680"; // light yellow hint color

  setTimeout(() => {
    cell.style.background = oldBg || "";
  }, 600);
}
function getHintIndex() {
  const human = "X";
  const ai = "O";

  const empties = board
    .map((v, i) => (v === null ? i : null))
    .filter(v => v !== null);

  if (empties.length === 0) return null;

  // 1. AI immediate win
  for (const idx of empties) {
    board[idx] = ai;
    if (checkWinner(board, boardSize, winLen)) {
      board[idx] = null;
      return idx;
    }
    board[idx] = null;
  }

  // 2. Human immediate win (block)
  for (const idx of empties) {
    board[idx] = human;
    if (checkWinner(board, boardSize, winLen)) {
      board[idx] = null;
      return idx;
    }
    board[idx] = null;
  }

  // 3. Center preference
  const center = Math.floor((boardSize * boardSize) / 2);
  if (board[center] === null) return center;

  // 4. Random fallback
  return empties[Math.floor(Math.random() * empties.length)];
}