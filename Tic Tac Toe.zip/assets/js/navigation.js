function goto(id) {
  if (id === "shop-screen") {
    coins = Number(localStorage.getItem("coins") || 0);
    hints = Number(localStorage.getItem("hints") || 0);
    renderShop();
  }
  document.querySelectorAll('.screen').forEach(s => s.classList.add('hidden'));
  const target = document.getElementById(id);
  if (target) target.classList.remove('hidden');
}
window.addEventListener('DOMContentLoaded', () => {
  const menuBtn = document.getElementById('menu-btn');
  const menuPopup = document.getElementById('menu-popup');
  
  if (!menuBtn || !menuPopup) {
    console.warn('Menu button or popup not found in DOM.');
    return;
  }
  menuBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    menuPopup.classList.toggle('hidden');
  });
});
